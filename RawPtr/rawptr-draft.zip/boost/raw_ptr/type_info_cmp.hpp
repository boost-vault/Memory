/** 
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */

#ifndef BOOST_RAW_PTR_TYPE_INFO_CMP_HPP
#define BOOST_RAW_PTR_TYPE_INFO_CMP_HPP

#include <typeinfo>

namespace boost {

class type_info_cmp
{
private:    
    typedef ::std::type_info std_ti;
    const std_ti* the_ti;
    //! Initialization helper
    template <typename T>
    const std_ti* init_by(void){return &typeid(T);}
    //! getter member function
    const std_ti& get(void) const {return *the_ti;}
public:
    //! Initialization from a type info reference
    type_info_cmp(const std_ti& a_ti):the_ti(&a_ti){ }
    template <typename T>
    //! initialization for a typed pointer
    type_info_cmp(T*):the_ti(init_by<T>()){ }
    //! assignment from a typed pointer
    template <typename T>
    type_info_cmp& operator = (T*){the_ti = init_by<T>(); return *this;}
    //
    /** @name Comparison operators */
    //@{
    friend bool operator == (const type_info_cmp& a, const type_info_cmp& b)
    {
        return a.get() == b.get();
    }
    friend bool operator != (const type_info_cmp& a, const type_info_cmp& b)
    {
        return a.get() != b.get();
    }
    friend bool operator <  (const type_info_cmp& a, const type_info_cmp& b)
    {
        return a.get().before(b.get());
    }
    friend bool operator >  (const type_info_cmp& a, const type_info_cmp& b)
    {
        return b.get().before(a.get()) && a.get() != b.get();
    }
    friend bool operator <= (const type_info_cmp& a, const type_info_cmp& b)
    {
        return a.get().before(b.get()) || a.get() == b.get();
    }
    friend bool operator >= (const type_info_cmp& a, const type_info_cmp& b)
    {
        return b.get().before(a.get()) || a.get() == b.get();
    }
    //@}
};


} /* namespace boost */

#endif // BOOST_RAW_PTR_TYPE_INFO_CMP_HPP 
