/*
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * This example shows the use of the raw_ptr in a very simplified reflection
 * facility. The raw_ptr is used instead of void* as the means to refer to
 * any instance of any type for which meta-data is available. The advantage
 * when compared to void* is the run-time type safety.
 *
 * For the sake of simplicity no error checking/handling is performed
 * as it should be in a real-life application.
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */

#include <iostream>
#include <utility>
#include <memory>
#include <map>
//
#include <boost/lexical_cast.hpp>
#include <boost/type_traits/alignment_of.hpp>
#include <boost/shared_ptr.hpp>
//
#include <boost/raw_ptr/raw_ptr.hpp>

using namespace ::std;
using namespace ::boost;

struct iMetaType
{
    /** public interface for a meta-type */
    virtual raw_ptr New(void) = 0;
    virtual raw_ptr NewInPlace(void* anArena) = 0;
    virtual void Delete(raw_ptr aPtr) = 0;
    virtual void DeleteInPlace(raw_ptr aPtr) = 0;
    virtual raw_ptr Clone(raw_ptr aPtr) = 0;
    virtual size_t SizeOf(void) = 0;
    virtual size_t Alignment(void) = 0;
    virtual void LoadFrom(raw_ptr aPtr, istream& aStream) = 0;
    virtual void SaveTo(raw_ptr aPtr, ostream& aStream) = 0;
    virtual void CastFrom(raw_ptr aPtr, const string& aStr) = 0;
    virtual ::std::string& CastTo(const raw_ptr aPtr, string& aStr) = 0;
    virtual bool Equal(const raw_ptr theFirst, const raw_ptr theSecond) = 0;
};


template <typename T>
class SimpleMetaType : public iMetaType
{
private:
    T* cast(raw_ptr& aPtr){return raw_cast<T*>(aPtr);}
    const T* cast(const raw_ptr& aPtr){return raw_cast<const T*>(aPtr);}
    T& deref(raw_ptr& aPtr){return *cast(aPtr);}
    const T& deref(const raw_ptr& aPtr){return *cast(aPtr);}
public:
    raw_ptr New(void){return new T();}
    raw_ptr NewInPlace(void* anArena){return new (anArena) T();}
    void Delete(raw_ptr aPtr){delete cast(aPtr);}
    void DeleteInPlace(raw_ptr aPtr){cast(aPtr)->~T();}
    raw_ptr Clone(raw_ptr aPtr){return new T(deref(aPtr));}
    size_t SizeOf(void){return sizeof(T);}
    size_t Alignment(void){return alignment_of<T>::value;}
    void LoadFrom(raw_ptr aPtr, istream& aStream)
    {
        aStream >> deref(aPtr);
    }
    void SaveTo(raw_ptr aPtr, ostream& aStream)
    {
        aStream << deref(aPtr);
    }
    void CastFrom(raw_ptr aPtr, const string& aStr)
    {
        deref(aPtr) = lexical_cast<T>(aStr);    
    }
    string& CastTo(const raw_ptr aPtr, string& aStr)
    {
        aStr = lexical_cast< string >(deref(aPtr));
        return aStr;
    }
    bool Equal(const raw_ptr theFirst, const raw_ptr theSecond)
    {
        return deref(theFirst) == deref(theSecond);
    }
};


typedef shared_ptr<iMetaType> IMetaType;
typedef map<string, IMetaType> MetaTypeMap;

/* NOTE: Of course in a real-life implementation there would be a typename
 * returning member function in the iMetaType interface itself
 */
void UseMetaData(const IMetaType& aMetaType, const string& aTypeName)
{
    assert(aMetaType);
    cout << "Working with a(n) " << aTypeName << endl;
    // create an instance and read a value from input 
    raw_ptr A = aMetaType->New();
    cout << "Enter a value (be careful what you enter): " << flush;
    aMetaType->LoadFrom(A, cin);
    // create and read another
    raw_ptr B = aMetaType->New();
    cout << "Enter another value: " << flush;
    aMetaType->LoadFrom(B, cin);
    // a compare them
    cout << "The values You entered are " << (aMetaType->Equal(A, B) ? "equal" : "not equal") << endl;
    //
    cout << "The instance size of this type is " << aMetaType->SizeOf() << " B" << endl;
    // etc.
    //
    // now clean up
    aMetaType->Delete(A);
    aMetaType->Delete(B);
}

#define RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MAP, SIMPLE_TYPE)\
    MAP[#SIMPLE_TYPE] = IMetaType(new SimpleMetaType<SIMPLE_TYPE>())

int main(int argc, const char* argv[])
{
    MetaTypeMap MetaTypes;
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, bool);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, char);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, short);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, int);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, signed int);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, unsigned int);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, long);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, float);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, double);
    RAW_PTR_TEST_REGISTER_SIMPLE_META_TYPE(MetaTypes, string);
    // etc.
    //
    string choice;
    while(1)
    {
        if(!cin) 
        {
            cerr << "Input error" << endl;
            break;
        }
        cout << "Enter a typename or type 'quit' to quit" << endl;
        cin >> choice;
        if(choice == "quit") break;
        IMetaType aMetaType = MetaTypes[choice];
        if(aMetaType) UseMetaData(aMetaType, choice);
        else cerr << "Unknown type" << endl;
    }
    cout << "Bye ... " << endl;
    //
    return 0;
}
