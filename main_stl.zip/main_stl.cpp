#include "cppgc.hpp"
#include "performancecounter.hpp"
#include <list>
#include <utility> //for std::pair
#include <iostream>

static PerformanceCounter pc1;
static PerformanceCounter pc2;

static const int kStretchTreeDepth = 18;
static const int kLongLivedTreeDepth = 16;
static const int kArraySize  = 500000;
static const int kMinTreeDepth = 4;
static const int kDifTreeDepth = 2;
static const int kNumTreeDepth = 2;
static const int kMaxTreeDepth = kMinTreeDepth+kNumTreeDepth*kDifTreeDepth;

  template 
  < class Node
  >
struct gc_ptr_node_std_list
: std::list
  < gc_ptr<Node> 
  , gc_allocator<gc_ptr<Node> >
  >
{
    gc_ptr_node_std_list(void)
    {
      gc_ptr<Node> empty_ptr;
      this->push_back(empty_ptr);
      this->push_back(empty_ptr);
    }
    gc_ptr_node_std_list(const gc_ptr<Node> &l, const gc_ptr<Node> &r) 
    {
      this->push_back(l);
      this->push_back(r);
    }
};
  template 
  < class GcPtrNode
  >
struct pair_as_list
: std::pair
  < GcPtrNode
  , GcPtrNode
  >
{
    pair_as_list(void) {
    }
    pair_as_list(const GcPtrNode &l, const GcPtrNode &r) {
      front()=l;
      back()=r;
    }
      GcPtrNode const&
    front(void)const
    {
        return this->first;
    }
      GcPtrNode const&
    back(void)const
    {
        return this->second;
    }
      GcPtrNode&
    front(void)
    {
        return this->first;
    }
      GcPtrNode&
    back(void)
    {
        return this->second;
    }
};

template
  < class T
  , class Allocator=std::allocator<T>
  > 
struct std_list 
//Purpose:
//  simplified std::list to test whether
//  gc'ed list can be created.
{
public:
    struct node
    //It's assumed that std::list uses something
    //like this to implement it's list, the only
    //essential difference being node_ptr.
    //In std::list, this would be node*.  OTOH,
    //in the gc'ed list, using a gc_allocator,
    //it would be gc_ptr<node>.
    {
        node(T const& a_elem)
          : _elem(a_elem)
        {}
          T
        _elem
        ;
            typedef
            typename
          Allocator::template rebind<node>::other
        allocator
        ;
            typedef
            typename
          allocator::pointer
        node_ptr
        ;
          node_ptr
        _prev
        ;
          node_ptr
        _next
        ;
    };
    
        typedef 
        typename 
      node::node_ptr 
    node_ptr
    ;
    
    std_list() {
        _begin = _end = 0;
    }

    ~std_list() {
        typename node::allocator node_allocator;
        node_ptr cur=_begin;
        while(cur)
        {
            node_ptr p=cur;
            cur=cur->_next;
            node_allocator.destroy(p);
        }
    }

    //get first element
    inline bool empty() const {
        return _begin == 0;
    }

    //get first element
    inline T const& front() const {
        return _begin->_elem;
    }

    //get end element
    inline T const& back() const {
        return _end->_elem;
    }

    //get first element
    inline T & front() {
        return _begin->_elem;
    }

    //get end element
    inline T & back() {
        return _end->_elem;
    }

    //adds an element as the last entry
    inline void push_back(T const& elem) {
        node_ptr new_node=new node(elem);
        if(empty())
        {
            _begin=new_node;
            _end=new_node;
        }
        else
        {
            new_node->_prev=_end;
            _end=new_node;
        }
    }

private:
    node_ptr _begin;
    node_ptr _end;
};
  template
  < class Node
  >
  struct
list_pair
  : std_list
    < Node
    , gc_allocator<Node>
    >
{
    list_pair(void)
    {
      Node empty_ptr;
      this->push_back(empty_ptr);
      this->push_back(empty_ptr);
    }
    list_pair(const Node &l, const Node &r) 
    {
      this->push_back(l);
      this->push_back(r);
    }
};      

  template
  < template <class> class GcPtrPair=pair_as_list
  >
struct Node {
    typedef gc_ptr<Node> node_ptr;
    GcPtrPair<node_ptr> left_right;
    
    Node() {
    }
    
    Node(const node_ptr &l, const node_ptr &r)
      : left_right(l,r)
    {
    }
      node_ptr const&
    left(void)const
    {
        return left_right.front();
    }
      node_ptr const&
    right(void)const
    {
        return left_right.back();
    }
      node_ptr&
    left(void)
    {
        return left_right.front();
    }
      node_ptr&
    right(void)
    {
        return left_right.back();
    }
};

  template
  < template <class> class GcPtrPair
  >
  std::string 
gc_ptr_pair_name
  (void)
;
  template
  <
  >
  std::string 
gc_ptr_pair_name
  < pair_as_list
  >
  (void)
{
    return "pair_as_list";
}
  template
  <
  >
  std::string 
gc_ptr_pair_name
  < list_pair
  >
  (void)
{
    return "list_pair";
}

  template
  < template <class> class GcPtrPair=pair_as_list
  >
struct GCBench {
    typedef Node<GcPtrPair> node_type;
    // Nodes used by a tree of a given size
    static int TreeSize(int i) {
        return ((1 << (i + 1)) - 1);
    }

    // Number of iterations to use for a given tree depth
    static int NumIters(int i) {
        return 2 * TreeSize(kStretchTreeDepth) / TreeSize(i);
    }

    // Build tree top down, assigning to older objects.
    static void Populate(int iDepth, const gc_ptr<node_type> &thisNode) {
        if (iDepth<=0) return;
        iDepth--;
        thisNode->left()  = gc_new node_type();
        thisNode->right() = gc_new node_type();
        Populate(iDepth, thisNode->left());
        Populate(iDepth, thisNode->right());
    }

    // Build tree bottom-up
    static gc_ptr<node_type> MakeTree(int iDepth) {
        if (iDepth <= 0) return gc_new node_type();
        return gc_new node_type(MakeTree(iDepth-1), MakeTree(iDepth-1));
    }

    static void TimeConstruction(int depth) {
        int iNumIters = NumIters(depth), i;
        gc_ptr<node_type> tempTree;

        printf("Creating %i trees of depth %i\n", iNumIters, depth);

        pc1.start();
        for (i = 0; i < iNumIters; ++i) {
            tempTree = gc_new node_type();
            Populate(depth, tempTree);
            tempTree = 0;
        }
        pc1.end();
        printf("\tTop down construction took %f msec\n", pc1.duration());

        pc1.start();
        for (i = 0; i < iNumIters; ++i) {
            tempTree = MakeTree(depth);
            tempTree = 0;
        }
        pc1.end();
        printf("\tBottom up construction took %f msec\n", pc1.duration());
    }

    void main() {
        gc_ptr<node_type> longLivedTree;
        gc_ptr<node_type> tempTree;

        printf("Garbage Collector Test\n");
        std::cout<<"GcPtrPair="<<gc_ptr_pair_name<GcPtrPair>()<<"\n";
        printf("Live storage will peak at %i  bytes.\n\n", 
			2 * sizeof(node_type) * TreeSize(kLongLivedTreeDepth) + sizeof(double) * kArraySize);
        
        printf("Stretching memory with a binary tree of depth %i\n", kStretchTreeDepth);
        pc2.start();
        tempTree = MakeTree(kStretchTreeDepth);
        tempTree = 0;
        
        printf("\nCreating a long-lived binary tree of depth %i\n", kLongLivedTreeDepth);
        longLivedTree = gc_new node_type();
        Populate(kLongLivedTreeDepth, longLivedTree);
        		
        printf("Creating a long-lived array of %i doubles\n", kArraySize);
        gc_ptr<double> array = gc_new double[kArraySize];
        for (int i = 0; i < kArraySize/2; ++i) {
            array[i] = 1.0/i;
        } 		       

        for (int d = kMinTreeDepth; d <= kMaxTreeDepth; d += kDifTreeDepth) {
            TimeConstruction(d);
        }

        pc2.end();
        longLivedTree = 0;
        tempTree = 0;
        array = 0;
        gc::collect_garbage();
        printf("Completed in %f msec\n", pc2.duration());
        printf("heap size = %u\n", gc::get_heap_size());
    }
};

  struct
obj_id
{
        static
      unsigned
    num_objs
    ;
    obj_id(void)
      : my_id(++num_objs)
    {}
    obj_id(obj_id const&)
      : my_id(++num_objs)
    {}
    ~obj_id(void)
    {
        --num_objs;
    }
      unsigned
    my_id
    ;
};

//        static
      unsigned
obj_id::      
    num_objs=0
    ;   

int main () 
{
  #if 1
    {
        std::cout<<"test:std_list<int>\n";
        {
            std_list<obj_id> list_obj;
            list_obj.push_back(obj_id());
            std::cout<<"front_list="<<list_obj.front().my_id<<"\n";
            std::cout<<"before list_obj.DTOR:num_objs="<<obj_id::num_objs<<"\n";
        }
        std::cout<<"after list_obj.DTOR:num_objs="<<obj_id::num_objs<<"\n";
    }
  #endif
  #if 1
    {
        std::cout<<"GCBench with std::pair\n";
        GCBench<> x;
        x.main();
    }
  #endif
  #if 1
    {
        std::cout<<"GCBench with std_list\n";
        GCBench<list_pair> x;
        x.main();
    }
  #endif
    return 0;
}
