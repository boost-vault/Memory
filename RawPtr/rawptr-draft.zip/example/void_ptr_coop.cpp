/*
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */
#include <assert.h>
#include <string.h> // memcpy, memcmp
//
#include <boost/raw_ptr/raw_ptr.hpp>
//
void Test(void);

int main(int argc, const char* argv[])
{
    Test();
    return 0;
}

struct POD
{
    double d;
    int i;
    long l;
    char c;
    bool b;
};

template <typename RawPointer>
void TestMemCpy(void)
{
    using namespace ::std;
    using namespace ::boost;
    //
    POD a = {12.34, 56, 789L, '0', false};    
    POD b;
    RawPointer pa(&a);
    RawPointer pb(&b);
    memcpy(raw_cast<void*>(pb), raw_cast<const void*>(pa), sizeof(POD));
    //
    // will crash if RawPointer == raw_ptr
    //
    // at this moment the raw_ptr intentionally does not support implicit
    // conversion to void* and if initialized with a typed pointer 
    // an explicit cast to void* is handled as a bad cast.
    // this behavior is intended as a safeguard against misuse 
    // in situation where the raw_ptr is not applicable as a replacement
    // for void*.
    // 
    assert(memcmp(raw_cast<const void*>(pa), raw_cast<const void*>(pb), sizeof(POD)) == 0);
}

void Test(void)
{
    TestMemCpy< void* >();
    // error at run-time
    TestMemCpy< ::boost::raw_ptr >();
}

