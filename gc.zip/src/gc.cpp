#include "gc.hpp"
#include <algorithm>
#include <boost/thread/locks.hpp>


//lock
#define _LOCK()\
    boost::lock_guard<boost::recursive_mutex> lock(_gc->m_mutex)


//init and lock
#define _INIT_AND_LOCK()\
    boost::call_once(_init_flag, &gc::_init);\
    _LOCK()


//init
void gc::ptr::_init(void *v) {
    _INIT_AND_LOCK();
    m_value = v;
    m_owner = &_gc->m_ptrs;
    _gc->m_ptrs.push_back(*this);
}


//dtor
gc::ptr::~ptr() {
    _LOCK();
    m_owner->erase(m_owner->iterator_to(*this));
}


//set value
void gc::ptr::set(void *v) {
    _LOCK();
    m_value = v;
}


//ctor; adds the block to the collector
gc::block::block(void *begin, size_t size, void (*deleter)(block *), ptr &pin) {
    _INIT_AND_LOCK();
    m_begin = (char *)begin;
    m_size = size;
    m_deleter = deleter;
    if (_heap_size + size > _heap_limit) _collect();
    m_marked = _marked;
    _gc->m_blocks.push_back(this);
    _heap_size += size;
    pin.m_value = begin;
}


//dtor; removes the block from the collector
gc::block::~block() {
    _LOCK();
    _gc->m_blocks.erase(std::find(_gc->m_blocks.rbegin(), _gc->m_blocks.rend(), this).base() - 1);
    _heap_size -= m_size;
}


//collect garbage
void gc::collect() {
    _INIT_AND_LOCK();
    _collect();
}


//get heap size
size_t gc::heap_size() {
    _INIT_AND_LOCK();
    return _heap_size;
}


//get heap limit
size_t gc::heap_limit() {
    _INIT_AND_LOCK();
    return _heap_limit;
}


//set heap limit
void gc::set_heap_limit(size_t limit) {
    _INIT_AND_LOCK();
    _heap_limit = limit;
}


//globals
boost::once_flag gc::_init_flag = BOOST_ONCE_INIT;
gc::_gc_t *gc::_gc = 0;
bool gc::_marked = false;
size_t gc::_heap_size = 0;
size_t gc::_heap_limit = 64 * 1024 * 1024;


//init; called once
void gc::_init() {
    _gc = new _gc_t;
    atexit(_cleanup);
}


//cleanup
void gc::_cleanup() {
    while (!_gc->m_blocks.empty()) {
        block *blk = _gc->m_blocks.back();
        blk->m_deleter(blk);
    }        
    delete _gc;
}


//collect garbage
void gc::_collect() {
    //we need the blocks sorted in order to quickly locate them
    std::sort(_gc->m_blocks.begin(), _gc->m_blocks.end(), _block_sort);
    
    //find the root and member ptrs
    _find_roots();
    
    //scan the block graph, staring from the root set
    
    //repeat until all objects reachable from deleted non-gc structures
    //are deleted as well
    for(;;) {
        size_t root_ptrs_before_collection = _gc->m_root_ptrs.size();
        _marked = !_marked;    
        _scan_ptrs(_gc->m_root_ptrs);
        _sweep();
        size_t root_ptrs_after_collection = _gc->m_root_ptrs.size();
        if (root_ptrs_before_collection == root_ptrs_after_collection) break;
    }
}


//block sort predicate
bool gc::_block_sort(const block *a, const block *b) {
    return a->m_begin < b->m_begin;
}


//finds the root and member ptrs
void gc::_find_roots() {
    for(boost::intrusive::list<ptr>::iterator it = _gc->m_ptrs.begin(); it != _gc->m_ptrs.end(); ) {
        ptr &p = *it++;
        _gc->m_ptrs.erase(_gc->m_ptrs.iterator_to(p));
        block *blk = _find_block(&p);
        if (blk) {
            blk->m_ptrs.push_back(p);
            p.m_owner = &blk->m_ptrs;
        }
        else {
            _gc->m_root_ptrs.push_back(p);
            p.m_owner = &_gc->m_root_ptrs;
        }
    }
}


//finds a block
gc::block *gc::_find_block(void *p) {
    if (_gc->m_blocks.empty() || (char *)p < _gc->m_blocks.front()->m_begin || (char *)p >= _gc->m_blocks.back()->m_begin + _gc->m_blocks.back()->m_size) return 0;
    static char fake_block[sizeof(block)];
    ((block &)fake_block).m_begin = (char *)p;
    std::vector<block *>::iterator it = std::upper_bound(_gc->m_blocks.begin(), _gc->m_blocks.end(), (block *)fake_block, _block_sort);
    block *blk = *--it;
    return (char *)p >= blk->m_begin && (char *)p < blk->m_begin + blk->m_size ? blk : 0;
}


//scans a ptr list
void gc::_scan_ptrs(boost::intrusive::list<ptr> &ptrs) {
    for(boost::intrusive::list<ptr>::iterator it = ptrs.begin(); it != ptrs.end(); ++it) {
        ptr &p = *it;
        block *blk = _find_block(p.m_value);
        if (blk) _mark_block(blk);
    }
}


//marks a block
void gc::_mark_block(block *blk) {
    if (blk->m_marked == _marked) return;
    blk->m_marked = _marked;
    _scan_ptrs(blk->m_ptrs);
}


//unreachable sort predicate when _marked == false
bool gc::_unreachable_sort_false(const block *a, const block *b) {
    return a->m_marked < b->m_marked;
}


//unreachable sort predicate when _marked == true
bool gc::_unreachable_sort_true(const block *a, const block *b) {
    return a->m_marked > b->m_marked;
}


//sweep unreachable
void gc::_sweep() {
    std::sort(_gc->m_blocks.begin(), _gc->m_blocks.end(), _marked ? &_unreachable_sort_true : &_unreachable_sort_false);
    while (!_gc->m_blocks.empty() && _gc->m_blocks.back()->m_marked != _marked) {
        block *blk = _gc->m_blocks.back();
        blk->m_deleter(blk);
    }        
}


//generic deleter
void gc_generic_delete(gc::block *blk) {
    blk->~block();
    ::operator delete(blk);
}


//generic array deleter
void gc_generic_delete_array(gc::block *blk) {
    blk->~block();
    ::operator delete[](blk);
}


//garbage collected generic operator new
void *operator new(size_t size, _gc_tag tag, gc::ptr &pin/* = gc::ptr()*/) {
    gc::block *blk = (gc::block *)::operator new(sizeof(gc::block) + size);
    return new (blk) gc::block(blk + 1, size, &gc_generic_delete, pin) + 1;
}


//garbage collected generic operator delete when an exception is thrown from the constructor
void operator delete(void *p, _gc_tag tag, gc::ptr &pin) {
    ((gc::block *)p - 1)->~block();
}


//garbage collected generic operator new
void *operator new[](size_t size, _gc_tag tag, gc::ptr &pin/* = gc::ptr()*/) {
    gc::block *blk = (gc::block *)::operator new[](sizeof(gc::block) + size);
    return new (blk) gc::block(blk + 1, size, &gc_generic_delete_array, pin) + 1;
}


//garbage collected generic operator delete when an exception is thrown from the constructor
void operator delete[](void *p, _gc_tag tag, gc::ptr &pin) {
    ((gc::block *)p - 1)->~block();
}


//garbage collected generic operator new
void *operator new(size_t size, void (*deleter)(gc::block *), gc::ptr &pin/* = gc::ptr()*/) {
    gc::block *blk = (gc::block *)::operator new(sizeof(gc::block) + size);
    return new (blk) gc::block(blk + 1, size, deleter, pin) + 1;
}


//garbage collected generic operator delete when an exception is thrown from the constructor
void operator delete(void *p, void (*deleter)(gc::block *), gc::ptr &pin) {
    ((gc::block *)p - 1)->~block();
}


//garbage collected generic operator new
void *operator new[](size_t size, void (*deleter)(gc::block *), gc::ptr &pin/* = gc::ptr()*/) {
    gc::block *blk = (gc::block *)::operator new[](sizeof(gc::block) + size);
    return new (blk) gc::block(blk + 1, size, deleter, pin) + 1;
}


//garbage collected generic operator delete when an exception is thrown from the constructor
void operator delete[](void *p, void (*deleter)(gc::block *), gc::ptr &pin) {
    ((gc::block *)p - 1)->~block();
}
