#ifndef BOOST_SHARED_NEW_HPP_INCLUDED
#define BOOST_SHARED_NEW_HPP_INCLUDED

// This is the maximum number of arguments to shared_new.
#ifndef BOOST_SHARED_NEW_MAX_ARITY
# define BOOST_SHARED_NEW_MAX_ARITY 9
#endif

#include <boost/shared_ptr.hpp>
#include <boost/preprocessor/repetition.hpp>

// Expands as: A0& a0, A1& a1, A2& a2, ... AN& aN
#define BOOST_SHARED_NEW_FUNC_ARG(z, n, unused) \
    BOOST_PP_CAT(A, n)& BOOST_PP_CAT(a, n)
#define BOOST_ENUM_SHARED_NEW_FUNC_ARGS(n) \
    BOOST_PP_ENUM(n, BOOST_SHARED_NEW_FUNC_ARG, ~)

namespace boost {

// Access class for shared_new<>.  Classes creatable only through
// shared_new declare this as a friend.
class shared_new_access {
    template<class T>
    static void
    destroy(T* t)
    {
        // Check that the type is complete first like
        // boost::checked_delete() does.  We'd just call
        // checked_delete(), but that function may not have access to
        // the destructor.
        typedef char type_must_be_complete[sizeof(T) ? 1 : -1];
        (void)sizeof(type_must_be_complete);

        delete t;
    }

#define BOOST_SHARED_ACCESS_CREATE_FUNCTION(z, n, unused)               \
    template<class T BOOST_PP_ENUM_TRAILING_PARAMS(n, class A)>         \
    static boost::shared_ptr<T>                                         \
    create(BOOST_ENUM_SHARED_NEW_FUNC_ARGS(n))                          \
    {                                                                   \
        return boost::shared_ptr<T>(new T(BOOST_PP_ENUM_PARAMS(n, a)),  \
            destroy<T>);                                                \
    }

    BOOST_PP_REPEAT(BOOST_SHARED_NEW_MAX_ARITY,
        BOOST_SHARED_ACCESS_CREATE_FUNCTION, ~)
#undef BOOST_SHARED_ACCESS_CREATE_FUNCTION

    // Give access to shared_new<>.
#define BOOST_SHARED_ACCESS_FRIEND_DECL(z, n, unused)           \
    template<class T BOOST_PP_ENUM_TRAILING_PARAMS(n, class A)> \
    friend boost::shared_ptr<T> shared_new(                     \
        BOOST_ENUM_SHARED_NEW_FUNC_ARGS(n));

    BOOST_PP_REPEAT(BOOST_SHARED_NEW_MAX_ARITY,
        BOOST_SHARED_ACCESS_FRIEND_DECL, ~)
#undef BOOST_SHARED_ACCESS_FRIEND_DECL

private:
    shared_new_access(); // no definition
};

// Implement the shared_new<> function template.
#define BOOST_SHARED_NEW_FUNCTION(z, n, unused)                 \
    template<class T BOOST_PP_ENUM_TRAILING_PARAMS(n, class A)> \
    boost::shared_ptr<T>                                        \
    shared_new(BOOST_ENUM_SHARED_NEW_FUNC_ARGS(n))              \
    {                                                           \
        return boost::shared_new_access::create<T>(             \
            BOOST_PP_ENUM_PARAMS(n, a));                        \
    }

BOOST_PP_REPEAT(BOOST_SHARED_NEW_MAX_ARITY, BOOST_SHARED_NEW_FUNCTION, ~)
#undef BOOST_SHARED_NEW_FUNCTION

}

#undef BOOST_SHARED_NEW_FUNC_ARG
#undef BOOST_ENUM_SHARED_NEW_FUNC_ARGS

#endif
