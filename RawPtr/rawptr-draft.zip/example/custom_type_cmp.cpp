/*
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */

#include <iostream>
#include <string.h>
//
#include <boost/raw_ptr/raw_ptr.hpp>

//template <typename T> const char* typeguid(T*);

class guid_cmp
{
private:
    typedef const char* guid_str;
    const guid_str the_guid;
    //! Initialization helper
    template <typename T>
    guid_str init_by(void){return typeguid((T*)0);}
public:
    //! initialization for a typed pointer
    template <typename T>
    guid_cmp(T*):the_guid(init_by<T>()){ }
    //! assignment from a typed pointer
    template <typename T>
    guid_cmp& operator = (T*){the_guid = init_by<T>(); return *this;}
    //
    /** @name Comparison operators */
    //@{
    friend bool operator == (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) == 0;
    }
    friend bool operator != (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) != 0;
    }
    friend bool operator <  (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) <  0;
    }
    friend bool operator >  (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) >  0;
    }
    friend bool operator <= (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) <= 0;
    }
    friend bool operator >= (const guid_cmp& a, const guid_cmp& b)
    {
        return strcmp(a.the_guid, b.the_guid) >= 0;
    }
    //@}
};

using namespace ::std;
using namespace ::boost;

/* Macro that declared a new overloaded version 
 * of the typeguid "operator"
 */
#define RAW_PTR_TEST_REGISTER_TYPEGUID(TYPE,GUID_STR) \
const char* typeguid(TYPE*) \
{\
        return GUID_STR;\
}

/* Register typeguid for some types */
RAW_PTR_TEST_REGISTER_TYPEGUID(void, "22BD2728-3262-489d-9874-085C8D187F65")
RAW_PTR_TEST_REGISTER_TYPEGUID(char, "BE648B70-DCE2-4d2d-AFFD-8B833841C781")
RAW_PTR_TEST_REGISTER_TYPEGUID(bool, "C0A0FC85-7A86-4eb4-9BBD-9874B1316A33")
RAW_PTR_TEST_REGISTER_TYPEGUID(short, "8BB33A36-1A58-4a73-AAAC-8924E10CD695")
RAW_PTR_TEST_REGISTER_TYPEGUID(int, "F0A24237-8564-467e-BC47-1F9822A8ACCE")
RAW_PTR_TEST_REGISTER_TYPEGUID(long, "175D92FA-CC59-40b6-9BE8-AEC86E3A0643")
RAW_PTR_TEST_REGISTER_TYPEGUID(float, "C1115C51-F34C-489f-ADD3-37DDB717337F")
RAW_PTR_TEST_REGISTER_TYPEGUID(double, "22B19335-ACBC-4942-9036-D82747777FC0")
RAW_PTR_TEST_REGISTER_TYPEGUID(string, "27F8D153-033E-4a16-8C81-5797764D6A8B")

struct S1 {int i;};
struct S2 {double d;};

RAW_PTR_TEST_REGISTER_TYPEGUID(S1, "5B519C03-F958-4832-8B79-E1A397CC89E1")
RAW_PTR_TEST_REGISTER_TYPEGUID(S2, "3F15CA28-7349-4c9a-86E8-76B012D76828")

/* Use the raw_ptr_templ to build a custom raw pointer */
typedef raw_ptr_templ<guid_cmp, throw_at_bad_cast_policy> custom_raw_ptr;

/* Test the raw pointer */
template <typename RawPtr>
void TestRawPtr(void)
{
        string str1 = "blah";
        RawPtr rpstr1 = &str1;
        cout << *raw_cast<string*>(rpstr1) << endl;
        //
        S1 s1 = {1};
        S2 s2 = {2.0};
        RawPtr rps1 = &s1;
        RawPtr rps2 = &s2;
        //
        S2* ps2 = raw_cast<S2*>(rps2); 
        cout << ps2->d << endl;
        ps2 = raw_cast<S2*>(rps1); //too bad
        cout << ps2->d << endl;
}

int main(int argc, const char* argv[])
{
        // use void*
        TestRawPtr<void*>();
        // use the custom raw ptr
        try{ TestRawPtr<custom_raw_ptr>(); }
        catch(bad_cast& e){cerr << "Error: " << e.what() << endl;}
        // use the default raw ptr
        TestRawPtr<raw_ptr>();
        return 0;
}
