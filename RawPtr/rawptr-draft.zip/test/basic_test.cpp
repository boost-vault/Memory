/*
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * This file is used for very basic testing and demonstration 
 * of the properties of the raw_ptr class and the raw_cast template. 
 * It focuses mainly on testing of the syntactical coherence of raw_ptr 
 * with the plain void* type and shows
 * the typechecking capabilities of the raw_ptr.
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */
#include <assert.h>
#include <iostream>
#include <string>
#include <map>
//
#include <boost/raw_ptr/raw_ptr.hpp>
#include <boost/lexical_cast.hpp>
//
#ifndef __BORLANDC__
// bcc32 (at least version 5.81) has issues with Boost.Function
#include <boost/function.hpp>
#endif

void Test1(int TestMode);

int main(int argc, const char* argv[])
{
    using namespace ::std;
    using namespace ::boost;
    //
    try
    {
        int mode = argc>1 ? lexical_cast<int>(argv[1]) : 0;
        Test1(mode);
    }
    catch(bad_cast& e)
    {
        cerr << "Invalid argument [" << argv[1] << "]" << endl;
        cout << "Simple test application for <raw_ptr>" << endl;
        cout << "Usage: " << argv[0] << " [0|1|2|3] " << endl;
        cout << " any of the listed values besides zero," << endl;
        cout << " given as the first argument, simulates" << endl;
        cout << " an invalid-cast-related bug and causes " << endl;
        cout << " the app to crash or to be aborted at " << endl;
        cout << " a certain stage of execution." << endl;
    }
    return 0;
}

template <typename T, class RawPointer>
struct factory_fn
{
    RawPointer operator()(void)
    {
        std::cout << "constructing" << std::endl;
        return new T();
    }
};

template <typename T, class RawPointer>
struct cleanup_fn
{
    void operator()(RawPointer a_ptr)
    {
        std::cout << "deleting" << std::endl;
        delete ::boost::raw_cast<T*>(a_ptr);
    }
};

/* Keeps the compilers from complaining about unused variables 
 * in the TestRawPtr template function in pedantic modes 
 */
//@{
template <typename SomeType>
void PretendUseOf(SomeType){ }
//@}


template <typename RawPointer, typename ConstRawPointer>
void TestRawPtr(int TestMode)
{
    // this shouldn't probably be done in real-life apps
    // but this is just a testbed
    using namespace ::std;
    using namespace ::boost;
    // 
    RawPointer uninitialized;
    PretendUseOf(uninitialized);
    //
    RawPointer initd_by_null_void = (void*)0;
    PretendUseOf(initd_by_null_void);
    //
    RawPointer initd_by_null_int = (int*)0;
    PretendUseOf(initd_by_null_int);
    //
    RawPointer initd_by_null_const = 0;
    PretendUseOf(initd_by_null_const);
    //
    int i = 110;
    PretendUseOf(i);
    const int ci = 0;
    PretendUseOf(ci);
    //
    RawPointer initd_by_int_addr = &i;
    PretendUseOf(initd_by_int_addr);
    ConstRawPointer initd_by_const_int_addr = &ci;
    PretendUseOf(initd_by_const_int_addr);
    const int *pci = raw_cast<const int*>(initd_by_const_int_addr);
    PretendUseOf(pci);
    //
    //int* hu = raw_cast<int*>(initd_by_const_int_addr); // won't compile
    // 
    //RawPointer initd_by_const_int_addr = &ci; //won't compile (const qualifier)
    //RawPointer initd_by_int_var = i; // won't compile
    RawPointer initd_by_int_var2 = ci;  
    PretendUseOf(initd_by_int_var2);
    //
    //
    uninitialized = NULL;
    PretendUseOf(uninitialized);
    uninitialized = 0;
    PretendUseOf(uninitialized);
    uninitialized = (int*)0;
    PretendUseOf(uninitialized);
    //uninitialized = i;    // won't compile
    uninitialized = ci; 
    PretendUseOf(uninitialized);
    //
    RawPointer initialized_1 = initd_by_null_void;
    PretendUseOf(initialized_1);
    RawPointer initialized_2 = initd_by_null_int;
    PretendUseOf(initialized_2);
    RawPointer initialized_3 = initd_by_int_addr;
    PretendUseOf(initialized_3);
    //
    // conversion to bool
    if(initd_by_int_addr)
    {
        int* pi = raw_cast<int*>(initd_by_int_addr);    
        assert(pi);
        // if the following lines are uncommented and mode == 1
        // the application possibly crashes due to 
        // a segmentation fault if not in the debugging mode 
        // or when using plain void*.
        // it is always aborted in the debugging mode
        // during the attempt to cast something that
        // was initialized as a pointer to int
        // to a pointer to double
        if(TestMode == 1)
        {
            // raw cast replaces the standard static_cast
            // for both raw_ptr and void* 
            double* pd = raw_cast<double*>(initd_by_int_addr);    
            assert(pd);
            cout << *pd << endl;
        }
    }
    // logical negation test
    if(!initd_by_int_addr)
    {
        int* pi = raw_cast<int*>(initd_by_int_addr);    
        assert(!pi);
    }
    // test of the comparison and assignment operators
    if(initd_by_null_void == initd_by_null_int)
        initd_by_null_int = 0;
    if(initd_by_null_int != initd_by_int_addr)
        initd_by_null_int = initd_by_int_addr;
    if(initd_by_null_void < initd_by_null_int)
        initd_by_null_void = initd_by_null_int;
    if(initd_by_null_void <= initd_by_null_int)
        initd_by_null_void = initd_by_null_int;
    if(initd_by_null_void > initd_by_null_int)
        initd_by_null_void = initd_by_null_int;
    if(initd_by_null_void >= initd_by_null_int)
        initd_by_null_void = initd_by_null_int;
    PretendUseOf(initd_by_null_void);
    //
    //
    // a table that contains default constructor 
    // and cleanup function wrappers.
    // in order to be able to stick these functors into
    // a map they need to have same return values 
    // and parameters, this is where a raw pointer is handy
    // 
    // during this test we just use the functions
    // pairwise to create a new instance and then to delete it
    // which is addmittedly not the best way to employ the
    // processors in real life applications but can be 
    // extended into something useful
#ifndef __BORLANDC__ /* bcc32 has issues with Boost.Function */
    typedef function0<RawPointer> factory_functor;
    typedef function1<void, RawPointer> cleanup_functor;
    typedef pair<factory_functor, cleanup_functor > factory_cleanup_fn_pair;
    typedef map<type_info_cmp, factory_cleanup_fn_pair> fn_list;
    fn_list l;
    const type_info_cmp ti_int((int*)0);
    const type_info_cmp ti_char((char*)0);
    const type_info_cmp ti_double((double*)0);
    const type_info_cmp ti_string((string*)0);
    const type_info_cmp ti_float((float*)0);
    //
    l[ti_int] = factory_cleanup_fn_pair(factory_fn<int, RawPointer>(), cleanup_fn<int, RawPointer>());
    l[ti_char] = factory_cleanup_fn_pair(factory_fn<char, RawPointer>(), cleanup_fn<char, RawPointer>());
    l[ti_double] = factory_cleanup_fn_pair(factory_fn<double, RawPointer>(), cleanup_fn<double, RawPointer>());
    l[ti_string] = factory_cleanup_fn_pair(factory_fn<string, RawPointer>(), cleanup_fn<string, RawPointer>());
    //
    // if the following line of code is uncommented it may or it may not result in a crash 
    // in non-debugging mode or when using plain void*.
    // rest assured it is definitelly not correct and can have other consequences besides segfaults.
    // when the typechecking is enabled the application is aborted gracefully allowing to
    // spot hidden bugs of this kind during debugging/testing phase
    if(TestMode == 2) l[ti_float] = factory_cleanup_fn_pair(factory_fn<double, RawPointer>(), cleanup_fn<int, RawPointer>());
    //
    for(typename fn_list::iterator I(l.begin());I!=l.end();++I)
        I->second.second(I->second.first());
#endif
    //
    cleanup_fn<int, RawPointer>()(factory_fn<int, RawPointer>()());
    if(TestMode == 3) cleanup_fn<string, RawPointer>()(factory_fn<float, RawPointer>()());
}

void Test1(int TestMode)
{
    TestRawPtr< void* , const void* >(TestMode);
    TestRawPtr< ::boost::raw_ptr, const ::boost::raw_ptr >(TestMode);
}

