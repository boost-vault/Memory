/** 
 * This file is part of a preliminary submission aimed to query the interest 
 * in a run-time typechecking replacement for the void*, to be included 
 * in the Boost library
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */
#ifndef BOOST_RAW_PTR_RAW_PTR_HPP
#define BOOST_RAW_PTR_RAW_PTR_HPP

#include <assert.h>
#include <stdlib.h> // abort()
#include <exception> // bad_cast
#include <boost/raw_ptr/type_info_cmp.hpp> // pointee type comparison/ordering
#include <boost/static_assert.hpp> // concept checking
#include <boost/type_traits.hpp> // concept checking
#include <boost/utility/enable_if.hpp> // enable_if


namespace boost {

template <class TypeCmp, typename BasePtrType>
class raw_ptr_base
{
protected:
    static BasePtrType null_ptr(void){return 0;}
    //! The raw pointer 
    BasePtrType the_ptr;
    //
    template <typename T>
    static BasePtrType adjust_ptr_type(T*& a_ptr, typename disable_if< is_function<T> >::type* blah = 0)
    {
        return const_cast<typename remove_const<T>::type* >(a_ptr);
    }
    //
    template <typename T>
    static BasePtrType adjust_ptr_type(T* a_ptr, typename enable_if< is_function<T> >::type* blah = 0)
    {
        return (BasePtrType)(a_ptr);
    }
/* TODO: it might be better to use another symbol than NDEBUG to allow
 * for better control as of when the type checking code will be 
 * included.
 */
#ifndef NDEBUG
    TypeCmp the_cmp;    
#endif
    //! Default construction    
    raw_ptr_base(void)
     : the_ptr(null_ptr())
#ifndef NDEBUG
     , the_cmp(null_ptr())
#endif
    { }
    //! Initialization
    template <typename T>
    raw_ptr_base(T* a_ptr)
     : the_ptr(adjust_ptr_type(a_ptr))
#ifndef NDEBUG
     , the_cmp((T*)0)
#endif
    { }
    //! Assignment
    template <typename T>
    void assign(T* a_ptr)
    {
        the_ptr = adjust_ptr_type(a_ptr); 
#ifndef NDEBUG
        the_cmp = (T*)0;
#endif
    }
    //! Cast possibility check
    template <typename T>
    bool cast_allowed(T*) const 
    {
#ifndef NDEBUG
        return the_cmp == TypeCmp((T*)0);
#else
        return true;
#endif
    }
};

struct do_nothing_at_bad_cast_policy
{
    static bool bad_cast_handler(void){return false;}
};

struct throw_at_bad_cast_policy
{
    static bool bad_cast_handler(void)
    {
        // TODO: own exception ?
        throw ::std::bad_cast();
    }
};

struct abort_at_bad_cast_policy
{
    static bool bad_cast_handler(void)
    {
        abort(); 
        return false;
    }
};

template <class TypeCmp, class BadCastPolicy, typename BasePtrType = void*>
class raw_ptr_templ
 : public raw_ptr_base<TypeCmp, BasePtrType>
 , protected BadCastPolicy
{
private:
    typedef raw_ptr_base<TypeCmp, BasePtrType> base_class;
    typedef BadCastPolicy bad_cast_policy;
    //
    //! Checks that the given integer has value of null
    void check_null_as_int(int supposed_null_addr)
    {
        // TODO: is this really a good idea ? 
        assert(supposed_null_addr == 0);
    }
    //
    //! does checks before the cast and performs some actions if necessary
    template <typename T>
    bool audit_cast(T*) const
    {
        // if the cast is allowed
        if(base_class::cast_allowed((T*)0))
            return true;
        //! use the policy's handler function
        return bad_cast_policy::bad_cast_handler();
    }
    //! No initialization from int&
    raw_ptr_templ(int&);
    //! No int& assignment
    raw_ptr_templ& operator = (int&);
public:
    typedef BasePtrType base_ptr_type;
    //! Default constructor
    raw_ptr_templ(void){ }
    //! initializing template constructor
    template <typename T>
    raw_ptr_templ(T* a_ptr)
     : base_class(a_ptr)
    { }
    //! Initialization from NULL
    raw_ptr_templ(const int supposed_null_addr)
    {
        check_null_as_int(supposed_null_addr);
    }
    //! assignment of an aritrary pointer
    template <typename T>
    raw_ptr_templ& operator = (T* a_ptr)
    {
        base_class::assign(a_ptr);
        return *this;
    }
    //! assignment of a 0 constant
    raw_ptr_templ& operator = (const int supposed_null_addr)
    {
        check_null_as_int(supposed_null_addr);
        base_class::assign(base_class::null_ptr());
        return *this;
    }
    //! Conversion to bool
    operator bool (void) const {return base_class::the_ptr;}
    //! Logical negation
    bool operator !(void) const {return !base_class::the_ptr;}
    //
    //! does the raw_cast 
    template <typename T>
    T* do_raw_cast(T*)
    {
        if(this->audit_cast((T*)0))
            return (T*)(this->the_ptr);
        else return (T*)0;
    }
    //! const raw_cast
    template <typename T>
    const T* do_raw_cast(const T*) const
    {
        if(this->audit_cast((const T*)0))
            return (const T*)(this->the_ptr);
        else return (const T*)0;
    }
};

template <typename T>
T raw_cast(void* a_ptr)
{
    BOOST_STATIC_ASSERT(is_pointer<T>::value);
    return static_cast<T>(a_ptr);
}

template <typename T>
T raw_cast(const void* a_ptr)
{
    BOOST_STATIC_ASSERT(is_pointer<T>::value);
    return static_cast<T>(a_ptr);
}

template <typename T>
T raw_cast(void(*a_ptr)(void))
{
    BOOST_STATIC_ASSERT(is_function<typename remove_pointer<T>::type>::value);
    return (T)(a_ptr);
}


template <typename T, class TypeCmp, class BadCastPolicy, typename BasePtrType>
T raw_cast(raw_ptr_templ<TypeCmp, BadCastPolicy, BasePtrType>& a_ptr)
{
    BOOST_STATIC_ASSERT(is_pointer<T>::value);
    return a_ptr.do_raw_cast((T)0);
}

template <typename T, class TypeCmp, class BadCastPolicy, typename BasePtrType>
T raw_cast(const raw_ptr_templ<TypeCmp, BadCastPolicy, BasePtrType>& a_ptr)
{
    BOOST_STATIC_ASSERT(is_pointer<T>::value);
    return a_ptr.do_raw_cast((T)0);
}

/** Declare the default type comparator and bad cast policy
 */
//@{
#ifndef NDEBUG /* Debug mode (kills sloppy apps ;) ) */
typedef type_info_cmp default_type_cmp;
typedef abort_at_bad_cast_policy default_bad_cast_policy;
#else /* Not debugging mode */
typedef type_info_cmp default_type_cmp;
typedef do_nothing_at_bad_cast_policy default_bad_cast_policy;
#endif
//@}
//
//! raw_ptr
typedef raw_ptr_templ<default_type_cmp, default_bad_cast_policy, void*> raw_ptr;
typedef raw_ptr_templ<default_type_cmp, default_bad_cast_policy, void(*)(void)> raw_fn_ptr;

} /* namespace boost */

#endif // BOOST_RAW_PTR_RAW_PTR_HPP
