/*
 * This file is part of a preliminary submission aimed to query the interest
 * in a run-time typechecking replacement for the void*, to be included
 * in the Boost library
 *
 * Copyright (C) Matus Chochlik, 2007, 2008
 * Use, modification and distribution is subject to the license included
 * with the source (See the accompanying LICENSE file)
 */

#include <iostream>
//
#include <boost/raw_ptr/raw_ptr.hpp>

using namespace ::std;
using namespace ::boost;

void f1(void){cout << "This is f1()" << endl;}
typedef void(*F1)(void);
//
double f2(int a, int b){return double(a)/double(b);}
typedef double(*F2)(int, int);
//
double f3(int a, int b){return double(a)*double(b);}


template <typename RawPtr>
void TestRawPtr(void)
{
#ifdef RAW_FN_PTR_TEST_COMPILE_ERROR_1
    RawPtr rp_f1_1 = f1; // won't compile
#endif
#ifdef RAW_FN_PTR_TEST_COMPILE_ERROR_2
    RawPtr rp_f1_2 = (RawPtr)f1; // won't compile
#endif
#ifdef RAW_FN_PTR_TEST_COMPILE_ERROR_3
    F1 p_f1_1 = raw_cast<F1>(RawPtr()); // won't compile
#endif
}

template <typename RawFnPtr>
void TestRawFnPtr(void)
{
    // default construction / no initialization
    RawFnPtr rfp_default;
    // initialization by function's address
    RawFnPtr rfp = RawFnPtr(f2); 
    //
    assert(rfp_default != rfp);
    // cast to the proper type
    cout << raw_cast<F2>(rfp)(12, 34) << endl;
    // assignment
    rfp = RawFnPtr(f3);
    // cast to the correct type
    cout << raw_cast<F2>(rfp)(23, 45) << endl;
    // cast to proper type and assignment to pointer
    F2 pf2 = raw_cast<F2>(rfp);
    // 
    cout << pf2(34, 56) << endl;
    rfp = f1;
    // cast to an incorrect type
    cout << raw_cast<F2>(rfp)(45, 67) << endl; // darn
}

int main(int argc, const char* argv[])
{
    TestRawPtr<void*>();
    TestRawPtr<raw_ptr>();
    //
    TestRawFnPtr<void(*)(void)>();
    TestRawFnPtr<raw_fn_ptr>();
    //
    return 0;
}
