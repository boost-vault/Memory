#include <boost/enable_shared_from_this.hpp> 
#include <boost/shared_ptr.hpp>

#include <set>

class shared_in_ctor : public boost::enable_shared_from_this<shared_in_ctor>
{
public:

	shared_in_ctor()
	{
		objects.insert(ctor_shared_from_this());
	}

	void test()
	{
		printf("test enable_shared_from_this\n");
	}

	~shared_in_ctor()
	{
		objects.insert(ctor_shared_from_this());
	}

private:
	static std::set<boost::shared_ptr<shared_in_ctor> > objects;
};

std::set<boost::shared_ptr<shared_in_ctor> > shared_in_ctor::objects;

void test_shared_in_ctor()
{
	shared_in_ctor x;
	x.test();
}
