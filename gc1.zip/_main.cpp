#include <vector>
#include <algorithm>
#include <boost/intrusive/slist.hpp>
#include <boost/intrusive/list.hpp>


struct _ptr : boost::intrusive::list_base_hook< boost::intrusive::link_mode<boost::intrusive::normal_link> > {
    void *m_value;
};    


typedef boost::intrusive::list<_ptr, boost::intrusive::constant_time_size<false> > _ptr_list;
    

struct _block : boost::intrusive::list_base_hook<boost::intrusive::link_mode<boost::intrusive::normal_link> > {
    _ptr_list m_ptrs;
    size_t m_size;
    void (*m_finalize)(void *);
    bool m_marked;
};


typedef boost::intrusive::list< _block> _block_list;


typedef std::vector<_block *> _block_vector;
    

_block_list _blocks;
_block_list _unreachable;
_block_vector _sorted_blocks;
_ptr_list _root_ptrs;
_ptr_list *_prev_ptrs;
_ptr_list *_ptrs = &_root_ptrs;
size_t _heap_size = 0;
size_t _heap_limit = 64 * 1024 * 1024;
bool _marked = false;


struct _tag {
};


namespace {
_tag _tag_;
}


template <class T> class gc_ptr : private _ptr {
public:
    gc_ptr(T *value = 0) {
        m_value = value;
        _ptrs->push_back(*this);
    }
    
    gc_ptr(const gc_ptr<T> &ptr) {
        m_value = ptr.m_value;
        _ptrs->push_back(*this);
    }
    
    ~gc_ptr() {
        _ptrs->erase(_ptrs->iterator_to(*this));
    }
    
    T *get() const {
        return reinterpret_cast<T *>(m_value);
    }
    
    operator T *() const {
        return get();
    }
    
    T *operator ->() const {
        BOOST_ASSERT(get());
        return get();
    }
    
    gc_ptr<T> &operator = (T *value) {
        m_value = value;
        return *this;
    }
    
    gc_ptr<T> &operator = (const gc_ptr<T> &ptr) {
        m_value = ptr.m_value;
        return *this;
    }
};


void _sort_blocks() {
    _sorted_blocks.clear();
    _sorted_blocks.reserve(_blocks.size());
    for(_block_list::iterator it = _blocks.begin(); it != _blocks.end(); ++it) {
        _sorted_blocks.push_back(&*it);        
    }    
    std::sort(_sorted_blocks.begin(), _sorted_blocks.end());
}


_block *_find_block(void *p) {
    _block_vector::iterator it = std::upper_bound(_sorted_blocks.begin(), _sorted_blocks.end(), (_block *)p);
    if (it == _sorted_blocks.begin()) return 0;
    --it;
    _block *blk = *it;
    return (char *)p >= (char *)(blk + 1) && (char *)p < (char *)blk + blk->m_size ? blk : 0;
}


void _scan(const _ptr_list &ptrs);


void _mark(_block *blk) {
    if (blk->m_marked == _marked) return;
    blk->m_marked = _marked;
    _scan(blk->m_ptrs);
}


void _scan(const _ptr_list &ptrs) {
    for(_ptr_list::const_iterator it = ptrs.begin(); it != ptrs.end(); ++it) {
        const _ptr &p = *it;
        _block *blk = _find_block(p.m_value);
        if (blk) _mark(blk);
    }
}


void _find_unreachable() {
    for(_block_list::iterator it = _blocks.begin(); it != _blocks.end(); ) {
        _block *blk = &*it;
        ++it;
        if (blk->m_marked != _marked) {
            _blocks.erase(_blocks.iterator_to(*blk));
            _unreachable.push_back(*blk);
        }
    }
}


void _finalize(_block *blk) {
    _unreachable.erase(_unreachable.iterator_to(*blk));
    _heap_size -= blk->m_size;
    blk->m_finalize(blk + 1);
    ::operator delete(blk);
}


void _finalize() {
    while (!_unreachable.empty()) {    
        for(_block_list::iterator it = _unreachable.begin(); it != _unreachable.end(); ++it) {
            _block *blk = &*it;
            _scan(blk->m_ptrs);
        }
        
        size_t blocks_before_finalization = _unreachable.size();
        
        for(_block_list::iterator it = _unreachable.begin(); it != _unreachable.end(); ) {
            _block *blk = &*it;
            ++it;
            if (blk->m_marked != _marked) _finalize(blk);
        }
        
        size_t blocks_after_finalization = _unreachable.size();
        
        if (blocks_before_finalization == blocks_after_finalization) {        
            while (!_unreachable.empty()) {
                _block *blk = &_unreachable.front();
                _finalize(blk);
            }
            return;
        }
        
        _marked = !_marked;
    }
}


void _sweep() {
    _find_unreachable();
    _finalize();
}


void _collect() {
    _marked = !_marked;
    _sort_blocks();
    _scan(_root_ptrs);
    _sweep();
}


void *_malloc(size_t size) {
    size += sizeof(_block);
    if (_heap_size + size > _heap_limit) _collect();
    _block *blk = (_block *)::operator new(size);
    new (blk) _block;
    blk->m_size = size;
    _prev_ptrs = _ptrs;
    _ptrs = &blk->m_ptrs;
    return blk + 1;
}


void _free(void *p) {
    _ptrs = _prev_ptrs;        
    ::operator delete(p);
}


template <class T> struct _finalizer {
    static void proc(void *p) {
        reinterpret_cast<T *>(p)->~T();
    }
};


struct _new {
    template <class T> gc_ptr<T> operator % (T *p) {
        _ptrs = _prev_ptrs;        
        _block *blk = reinterpret_cast<_block *>(p) - 1;        
        blk->m_finalize = _finalizer<T>::proc;
        blk->m_marked = _marked;
        gc_ptr<T> r(p);
        _blocks.push_back(*blk);
        _heap_size += blk->m_size;
        return r;
    }
};


void *operator new(size_t size, _tag t) {
    return _malloc(size);
}


void operator delete(void *p, _tag t) {
    _free(p);
}


void *operator new[](size_t size, _tag t) {
    throw 0;
    return _malloc(size);
}


void operator delete[](void *p, _tag t) {
    _free(p);
}


#define gc_new _new() % new(_tag_)


/******************************************************************************/


#include <iostream>
using namespace std;


int id = 0;


struct Foo {
public:
    int m_id;
    gc_ptr<Foo> m_next;
    
    Foo() : m_id(id++) {
    }
    
    ~Foo() {
        cout << "deleted " << m_id << "\n";
    }
};


int main() {
    gc_ptr<Foo> foo1 = gc_new Foo;
    foo1->m_next = gc_new Foo;
    
    gc_ptr<Foo> foo2 = gc_new Foo;
    foo2->m_next = gc_new Foo;
    
    //foo2->m_next->m_next = foo1;
    
    foo1 = 0;
    foo2 = 0;
    
    _collect();
    
    cout << "heap size = " << _heap_size << endl;
    getchar();
    return 0;
}


/*
    the code above is a garbage collector with the following differences from the previous one:
    
    1) finalization order that respects destructor semantics, except when there are cycles.
        In the previous collector, the order of finalization is random.
        
    2) O(1) detection of member ptrs: pointers registers themselves to the appropriate ptr list
       as they are created. In the previous collector, pointers where discovered in the collection
       phase by look-up on the sorted blocks.
       
    Missing features:       
    
    1) new[] does not work.
    2) no thread support.
    3) no user-defined allocation.
    
    The code is published for discussing possible ideas about implementations.
 */
