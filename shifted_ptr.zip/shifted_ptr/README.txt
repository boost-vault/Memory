Unless otherwise specified, terms and conditions of use for Boost software
and documentation are described in the accompanying license. See the file
named LICENSE in the top-level directory.

For the most current version of Boost libraries and documentation, see:

   http://www.boost.org

Boost documentation is in HTML format.

The top-level directory (which contains this README file) should contain
a file named index.htm with links to all documentation, including
documentation on building boost libraries for your particular compiler
and operating system.
