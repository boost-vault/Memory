#include <conio.h>
#include <time.h>
#include <iostream>
#include <list>
#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/pool/pool.hpp>
#include "gc.hpp"
using namespace std;
using namespace boost;


class Foo : public gc_object<Foo> {
public:
    gc_ptr<Foo> m_next;
    shared_ptr<list<gc_ptr<Foo> > > m_children;
    
    Foo() {
    }
    
    template <class T> Foo(T ex) {
        throw ex;
    }
};


mutex foo_mutex;
pool<> foo_pool(sizeof(gc::block) + sizeof(Foo));


template <> class gc_malloc<Foo> {
public:
    static void *proc(size_t size) {
        lock_guard<mutex> lock(foo_mutex);
        return foo_pool.malloc();
    }
};


template <> class gc_free<Foo> {
public:
    static void proc(void *p) {
        lock_guard<mutex> lock(foo_mutex);
        foo_pool.free(p);
    }
};


class Bar {
public:
};


void test_primitive() {
    gc_ptr<double> data = gc_new double[1000];
    for(int i = 0; i < 1000; ++i) data[i] = 0;
        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(double[1000]));

    for(int i = 0; i < 1000; ++i) data[i] *= 2;
    
    data = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_simple() {
    gc_ptr<Foo> foo1 = new Foo;
    
    new gc_wrapper<Bar>;
        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(Foo));

    foo1 = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}

    
void test_cycle() {    
    gc_ptr<Foo> foo1 = new Foo;
    foo1->m_next = new Foo;
    foo1->m_next->m_next = foo1;
        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(Foo) * 2);

    foo1 = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_array() {
    gc_ptr<Foo> foo1 = new Foo[10];
        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(Foo) * 10 + 4);

    foo1 = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_array_cycle() {
    gc_ptr<Foo> foo1 = new Foo[10];
    foo1 += 5;
    foo1->m_next = new Foo[10];
    foo1->m_next += 5;
    foo1->m_next->m_next = foo1;
        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(Foo) * 20 + 8);

    foo1 = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_exception_in_constructor() {
    try {
        gc_ptr<Foo> foo1 = new Foo(std::bad_alloc());
    }
    catch (...) {
    }
        
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_stl() {
    gc_ptr<Foo> foo1 = new Foo;
    foo1->m_children = shared_ptr<list<gc_ptr<Foo> > >(new list<gc_ptr<Foo> > );
    foo1->m_children->push_back(new Foo);
    
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == sizeof(Foo) * 2);

    foo1 = 0;        
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


const int MAX_OBJECTS = 100000;


void test_performance() {
    static gc_ptr<Foo> objects[MAX_OBJECTS];
    for(int i = 0; i < MAX_OBJECTS; ++i) {
        objects[i] = new Foo;
    }
    for(int i = MAX_OBJECTS / 2; i < MAX_OBJECTS; ++i) {
        objects[i] = 0;
    }
    clock_t start = clock();
    gc::collect();
    clock_t end = clock();
    cout << "collecting " << MAX_OBJECTS/2 << " out of " << MAX_OBJECTS << " objects took " << ((end - start)*1000/CLOCKS_PER_SEC) << " msecs\n";
}


void test_loop() {
    for(int i = 0; i < MAX_OBJECTS; ++i) {
        gc_ptr<Foo> foo1 = new Foo;
        foo1->m_next = new Foo;
        foo1->m_next->m_next = foo1;
    }
}


void test_allocation_loop() {
    test_loop();    
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


void test_threads() {
    const int MAX_THREAD = 10;
    
    thread* thr[MAX_THREAD];
    
    for(int i = 0; i < MAX_THREAD; ++i) {
        thr[i] = new thread(test_loop);
    }
    
    for(int i = 0; i < MAX_THREAD; ++i) {
        thr[i]->join();
        delete thr[i];
    }
    
    gc::collect();
    BOOST_ASSERT(gc::heap_size() == 0);
}


int main() {
    test_primitive();
    test_simple();
    test_cycle();
    test_array();
    test_array_cycle();
    test_exception_in_constructor();
    test_stl();
    test_performance();
    test_allocation_loop();
    test_threads();
    cout << "collector test finished. Press any key...";
    getch();
    return 0;
}
