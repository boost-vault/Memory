#include "shared_new.hpp"
#include <boost/shared_ptr.hpp>

namespace {

struct X {
    void foo() {}

private:
    // Private constructor and destructor are only accessible through
    // boost::shared_new<>.
    friend class boost::shared_new_access;
    explicit X(int foo) {}
    ~X() {}
};

struct normal {};

}

int
main()
{
    int const int_foo = 12;
    boost::shared_ptr<X> p = boost::shared_new<X>(int_foo);

    p->foo();

    //delete p.get(); // compiler error
    //boost::shared_new_access::destroy(p.get()); // compiler error

    boost::shared_ptr<normal> pn = boost::shared_new<normal>();
}
