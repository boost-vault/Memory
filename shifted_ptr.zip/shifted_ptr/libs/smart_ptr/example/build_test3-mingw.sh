g++ shifted_ptr_test3.cpp -I ../../.. /local/lib/boost_unit_test_framework-mt.lib -Wl,--enable-runtime-pseudo-reloc -ggdb3
