#ifndef GC_HPP
#define GC_HPP


/**@file*/


#include <vector>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/thread/once.hpp>
#include <boost/intrusive/list.hpp>
#include <boost/noncopyable.hpp>
#include <boost/type_traits/has_trivial_destructor.hpp>


/** static class with garbage collection methods and classes.
 */
class gc {
public:
    /** a generic garbage-collected ptr.
     */
    class ptr : public boost::intrusive::list_base_hook<> {
    private:
        //attrs
        void *m_value;
        boost::intrusive::list<ptr> *m_owner;
        
        //init
        void _init(void *v);
    
    public:
        /** the default constructor.
            It adds the pointer to the collector.
            A synchronized operation.
            @param v initial pointer value.
         */
        ptr(void *v = 0) {
            _init(v);
        }
        
        /** the copy constructor.
            It adds the pointer to the collector.
            A synchronized operation.
            @param p source object.
         */
        ptr(const ptr &p) {
            _init(p.m_value);
        }
        
        /** the destructor.
            It removes the pointer from the collector.
            A synchronized operation.
         */
        ~ptr();
        
        /** the assignment operator.
            @param p source object.
            A synchronized operation.
            @return reference to this.
         */
        ptr &operator = (const ptr &p) {
            set(p.m_value);
            return *this;
        }
        
        /** automatic conversion to ptr.
            @return raw ptr value.
         */
        operator void *() const {
            return m_value;
        }         
        
        /** retrieves the value of the pointer.
            @return the value of the pointer.
         */
        void *get() const {
            return m_value;
        }
        
        /** sets the value of the pointer.
            A synchronized operation.
            @param v new pointer value.
         */
        void set(void *v);
        
    private:        
        friend class gc;
    };
    
    /** a garbage-collected memory block.
        Instances of these must be kept around while the heap memory is not deallocated.
     */
    class block : public boost::noncopyable {
    public:
        /** the constructor.
            It registers the block to the collector.
            A synchronized operation.
            If the heap limit is exceeded, garbage will collected.
            @param begin the pointer to the actual memory block.
            @param size number of allocated bytes.
            @param deleter the block's deleter; it should not be null. 
                It is invoked to delete the block, run the finalization and
                deallocate the memory occupied by the collector.
            @param pin temporary root pointer used for keeping the block 
                from being collected while it is being initialized.
         */
        block(void *begin, size_t size, void (*deleter)(block *), ptr &pin);
        
        /** the destructor.
            It removes the block from the collector.
            A synchronized operation.
         */
        ~block();
        
        /** returns the start address of the block.
            @return the start of the block.
         */
        void *begin() const {
            return m_begin;
        }
        
        /** returns the block's size, in bytes.
            @return the block's size, in bytes.
         */
        size_t size() const {
            return m_size;
        }
        
    private:
        //attrs
        char *m_begin;
        bool m_marked;        
        size_t m_size;
        void (*m_deleter)(block *);
        boost::intrusive::list<ptr> m_ptrs;
        
        friend class gc;
    };
    
    /** collects garbage.
        A synchronized operation.
     */
    static void collect();
    
    /** returns the heap size.
        A synchronized operation.
        @return the number of bytes registered to the collector.
     */
    static size_t heap_size();

    /** returns the heap limit.
        A synchronized operation.
        @return the number of bytes that, when exceeded, will trigger a collection.
     */
    static size_t heap_limit();
    
    /** sets the heap limit.
        A synchronized operation.
        @param limit the number of bytes that, when exceeded, will trigger a collection.
     */
    static void set_heap_limit(size_t limit);

private:
    //holds the static gc context that must be initialized
    struct _gc_t {
        boost::recursive_mutex m_mutex;
        boost::intrusive::list<ptr> m_ptrs;
        boost::intrusive::list<ptr> m_root_ptrs;
        std::vector<block *> m_blocks;
    };
    
    //globals
    static boost::once_flag _init_flag;
    static _gc_t *_gc;
    static bool _marked;
    static size_t _heap_size;
    static size_t _heap_limit;
    
    //init; called once
    static void _init();
    
    //cleanup; called at exit
    static void _cleanup();
    
    //collect garbage
    static void _collect();
    
    //block sort predicate
    static bool _block_sort(const block *a, const block *b);
    
    //finds the root and member ptrs
    static void _find_roots();
    
    //finds a block
    static block *_find_block(void *p);
    
    //scans a ptr list
    static void _scan_ptrs(boost::intrusive::list<ptr> &ptrs);
    
    //marks a block
    static void _mark_block(block *blk);
    
    //unreachable sort predicate when _marked == false
    static bool _unreachable_sort_false(const block *a, const block *b);
    
    //unreachable sort predicate when _marked == true
    static bool _unreachable_sort_true(const block *a, const block *b);
    
    //sweep unreachable
    static void _sweep();
};


/** a template class which runs the finalizer for type T.
    The default implementation invokes the destructor of T.
    @param T type of object to finalize.
 */
template <class T> class gc_finalize {
public:
    /** the finalization procedure.
        It invokes ~T().
        @param p pointer to memory as passed to gc::block.
     */
    static void proc(void *p) {
        ((T *)p)->~T();
    }
};

    
/** a finalizer for an array of T.
    It invokes the destructor of T for each member of the array.
    The length of the array is discovered by the first sizeof(size_t) bytes of the array.
    The above takes place only if T has no trivial destructor.
    @param T type of object to finalize.
 */
template <class T> class gc_finalize_array {
public:
    /** the finalization procedure.
        It invokes ~T() for each menber of the array.
        @param p pointer to memory as passed to gc::block.
     */
    static void proc(void *p) {
        if (boost::has_trivial_destructor<T>::value) return;
        size_t length = *(size_t *)p;
        for(T *begin = (T *)((size_t *)p + 1), *end = begin + length; begin < end; ++begin) begin->~T();
    }
};


/** class for controlling memory allocation for type T.
    The default implementation returns ::operator_new(size).
    @param T type of class to control the allocation of.
 */
template <class T> class gc_malloc {
public:
    /** the malloc procedure.
        @param size number of bytes to allocate.
        @return pointer to allocated memory.
     */
    static void *proc(size_t size) {
        return ::operator new(size);
    }
};


/** class for controlling memory allocation for type T[].
    The default implementation returns ::operator_new[](size).
    @param T type of class to control the allocation of.
 */
template <class T> class gc_malloc_array {
public:
    /** the malloc procedure.
        @param size number of bytes to allocate.
        @return pointer to allocated memory.
     */
    static void *proc(size_t size) {
        return ::operator new[](size);
    }
};


/** class for controlling memory deallocation for type T.
    The default implementation invokes ::operator_delete(p).
    @param T type of class to control the deallocation of.
 */
template <class T> class gc_free {
public:    
    /** the free procedure.
        @param p pointer to memory as passed to gc::block.
     */
    static void proc(void *p) {
        ::operator delete(p);
    }
};


/** class for controlling memory deallocation for type T.
    The default implementation invokes ::operator_delete[](p).
    @param T type of class to control the deallocation of.
 */
template <class T> class gc_free_array {
public:    
    /** the free procedure.
        @param p pointer to memory as passed to gc::block.
     */
    static void proc(void *p) {
        ::operator delete[](p);
    }
};


/** the default block deleter.
    It invokes the finalizer of T, then it invokes ~gc::block(), then it frees
    the memory occupied by the block.
    It supposes that T is right after the block.
 */
template <class T> class gc_delete {
public:
    /** the delete procedure.
        @param blk the memory block to delete.
     */
    static void proc(gc::block *blk) {
        gc_finalize<T>::proc(blk->begin());
        blk->~block();
        gc_free<T>::proc(blk);
    }  
};
      

/** the default array block deleter.
    It invokes the finalizer of T[], then it invokes ~gc::block(), then it frees
    the memory occupied by the block.
    It supposes that T[] is right after the block.
 */
template <class T> class gc_delete_array {
public:
    /** the delete procedure.
        @param blk the memory block to delete.
     */
    static void proc(gc::block *blk) {
        gc_finalize_array<T>::proc(blk->begin());
        blk->~block();
        gc_free_array<T>::proc(blk);
    }
};
    
    
/** base class for objects that want to register themselves to the collector.
    It provides the appropriate new and delete operators.
    @param T type of derived class.
 */
template <class T> class gc_object {
public:
    /** allocates a garbage-collected object.
        It allocates a gc::block instance together with the memory block.
        @param size number of bytes to allocate.        
        @param pin temporary root pointer used for keeping the block 
            from being collected while it is being initialized.
     */
    void *operator new(size_t size, gc::ptr &pin = gc::ptr()) {
        gc::block *blk = (gc::block *)gc_malloc<T>::proc(sizeof(gc::block) + size);
        return new (blk) gc::block(blk + 1, size, &gc_delete<T>::proc, pin) + 1;
    }    
    
    /** the operator delete invoked in the case of exception in the constructor.
        It invokes the destructor of the gc::block which is in front of T, thus
        removing the object from the collector.
        @param p pointer to memory block as returned by operator new.
        @param pin temporary root pointer passed in operator new.        
     */
    void operator delete(void *p, gc::ptr &pin) {
        ((gc::block *)p - 1)->~block();
    }
        
    /** the normal operator delete.
        It invokes the destructor of the gc::block which is in front of T, thus
        removing the object from the collector.
        @param p pointer to memory block as returned by operator new.
     */
    void operator delete(void *p) {
        ((gc::block *)p - 1)->~block();
    }
    
    /** allocates a garbage-collected array of objects.
        It allocates a gc::block instance together with the memory block.
        @param size number of bytes to allocate.        
        @param pin temporary root pointer used for keeping the block 
            from being collected while it is being initialized.
     */
    void *operator new[](size_t size, gc::ptr &pin = gc::ptr()) {
        gc::block *blk = (gc::block *)gc_malloc_array<T>::proc(sizeof(gc::block) + size);
        return new (blk) gc::block(blk + 1, size, gc_delete_array<T>::proc, pin) + 1;
    }    
        
    /** the operator delete invoked in the case of exception in the constructor.
        It invokes the destructor of the gc::block which is in front of T[], thus
        removing the object from the collector.
        @param p pointer to memory block as returned by operator new[].
        @param pin temporary root pointer passed in operator new[].
     */
    void operator delete[](void *p, gc::ptr &pin) {
        ((gc::block *)p - 1)->~block();
    }
    
    /** the normal operator delete[].
        It invokes the destructor of the gc::block which is in front of T[], thus
        removing the object from the collector.
        @param p pointer to memory block as returned by operator new[].
     */
    void operator delete[](void *p) {
        ((gc::block *)p - 1)->~block();
    }    
};


/** gc wrapper for objects that inherit from another non-gc class.
    @param T type of base class.
 */
template <class T> class gc_wrapper : public T, public gc_object<gc_wrapper<T> > {
public:
    /** the default constructor.
     */
    gc_wrapper() {
    }
    
    /** constructor from base class object.
        @param b instance of base class.
     */
    gc_wrapper(const T &b) : T(b) {
    }
};


/** a garbage-collected pointer.
    It adds a type to gc::ptr, as well as being a garbage-collected object itself.
    @param T pointer to garbage-collected data (or to anything else).
 */
template <class T> class gc_ptr : public gc::ptr, public gc_object<gc_ptr<T> > {
public:
    /** the default constructor.
        @param v initial value.
     */
    gc_ptr(T *v = 0) : gc::ptr(v) {
    }
    
    /** the default constructor.
        @param p source object.
     */
    gc_ptr(const gc_ptr<T> &p) : gc::ptr(p) {
    }
        
    /** the destructor.
     */
    ~gc_ptr() {
    }
    
    /** the assignment operator.
        @param p source object.
        @return reference to this.
     */
    gc_ptr<T> &operator = (const gc_ptr<T> &p) {
        gc::ptr::operator = (p);
        return *this;
    }
    
    /** get value of ptr.
        @return raw pointer to object.
     */
    T *get() const {
        return (T *)gc::ptr::get();
    }
        
    /** automatic conversion to ptr.
        @return raw ptr value.
     */
    operator T *() const {
        return get();
    }    
    
    /** member access.
        @return raw pointer to object.
     */
    T *operator ->() const {
        BOOST_ASSERT(get());
        return get();
    }
    
    /** sets the ptr value.
        @param v new value.
        @return reference to this.
     */
    gc_ptr<T> &operator = (T *v) {
        gc::ptr::operator = (v);
        return *this;
    }
    
    /** increases the pointer.
        @param i value to increase the ptr by.
        @return reference to this.
     */
    gc_ptr<T> &operator += (int i) {
        gc::ptr::set(get() + i);
        return *this;
    }
       
    /** decreases the pointer.
        @param i value to decrease the ptr by.
        @return reference to this.
     */
    gc_ptr<T> &operator -= (int i) {
        gc::ptr::set(get() - i);
        return *this;
    }
        
    /** increments the pointer (prefix operator).
        @return reference to this.
     */
    gc_ptr<T> &operator ++ () {
        gc::ptr::set(++get());
        return *this;
    }
            
    /** decrements the pointer (prefix operator).
        @return reference to this.
     */
    gc_ptr<T> &operator -- () {
        gc::ptr::set(--get());
        return *this;
    }
            
    /** increments the pointer (postfix operator).
        @return value before this is incremented.
     */
    gc_ptr<T> operator ++ (int i) {
        gc_ptr<T> result = get();
        gc::ptr::set(++get());
        return result;
    }
            
    /** decrements the pointer (postfix operator).
        @return value before this is incremented.
     */
    gc_ptr<T> operator -- (int i) {
        gc_ptr<T> result = get();
        gc::ptr::set(--get());
        return result;
    }
};


//used for operator new
struct _gc_tag {
};


namespace {
//used for operator new
_gc_tag gc_tag;
}


/** garbage-collected operator new macro.
    It allows the allocation of objects that do not have a finalizer.
 */
#ifndef gc_new
#define gc_new new(gc_tag)
#endif


/** generic delete.
    It does invoke any finalizer.
    @param blk pointer to generic block to delete.
 */
void gc_generic_delete(gc::block *blk);


/** generic array delete.
    It does invoke any finalizer of the array.
    @param blk pointer to generic block to delete.
 */
void gc_generic_delete_array(gc::block *blk);


/** garbage collected generic operator new.
    @param size number of bytes to allocate.
    @param tag internal tag used for the macro gc_new.
    @param pin temporary root pointer used for keeping the block 
        from being collected while it is being initialized.
    @return pointer to allocated memory.        
 */
void *operator new(size_t size, _gc_tag tag, gc::ptr &pin = gc::ptr());


/** garbage collected generic operator delete when an exception is thrown.
    @param p pointer to memory block as returned by operator new.
    @param tag internal tag used for the macro gc_new.
    @param pin temporary root pointer passed in operator new.
 */
void operator delete(void *p, _gc_tag tag, gc::ptr &pin);


/** garbage collected generic operator new[].
    @param size number of bytes to allocate.
    @param tag internal tag used for the macro gc_new.
    @param pin temporary root pointer used for keeping the block 
        from being collected while it is being initialized.
    @return pointer to allocated memory.        
 */
void *operator new[](size_t size, _gc_tag tag, gc::ptr &pin = gc::ptr());


/** garbage collected generic operator delete when an exception is thrown.
    @param p pointer to memory block as returned by operator new[].
    @param tag internal tag used for the macro gc_new.
    @param pin temporary root pointer passed in operator new[].
 */
void operator delete[](void *p, _gc_tag tag, gc::ptr &pin);


/** garbage collected generic operator new with a custom deleter.
    @param size number of bytes to allocate.
    @param deleter a custom deleter.
    @param pin temporary root pointer used for keeping the block 
        from being collected while it is being initialized.
    @return pointer to allocated memory.        
 */
void *operator new(size_t size, void (*deleter)(gc::block *), gc::ptr &pin = gc::ptr());


/** garbage collected generic operator delete when an exception is thrown.
    @param p pointer to memory block as returned by operator new.
    @param deleter a custom deleter.
    @param pin temporary root pointer passed in operator new.
 */
void operator delete(void *p, void (*deleter)(gc::block *), gc::ptr &pin);


/** garbage collected generic operator new with a custom deleter.
    @param size number of bytes to allocate.
    @param deleter a custom deleter.
    @param pin temporary root pointer used for keeping the block 
        from being collected while it is being initialized.
    @return pointer to allocated memory.        
 */
void *operator new[](size_t size, void (*deleter)(gc::block *), gc::ptr &pin = gc::ptr());


/** garbage collected generic operator delete when an exception is thrown.
    @param p pointer to memory block as returned by operator new[].
    @param deleter a custom deleter.
    @param pin temporary root pointer passed in operator new[].
 */
void operator delete[](void *p, void (*deleter)(gc::block *), gc::ptr &pin);


#endif //GC_HPP
